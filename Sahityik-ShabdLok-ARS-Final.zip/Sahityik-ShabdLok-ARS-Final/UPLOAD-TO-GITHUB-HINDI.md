# ZIP से वेबसाइट सही तरह GitHub पर अपलोड करने का तरीका

## सबसे ज़रूरी बात
ZIP फ़ाइल को repository में सिर्फ़ upload कर देने से वेबसाइट की फाइलें अपने-आप publish नहीं होतीं। ZIP को अपने कंप्यूटर पर **Extract All** करें और उसके अंदर की फाइलें repository के मुख्य स्तर (root) पर upload करें।

## चरण
1. ZIP पर right-click करें → **Extract All**.
2. निकले हुए folder में `index.html`, `styles.css`, `app.js` दिखाई देने चाहिए।
3. GitHub पर अपनी `Sahityik-ShabdLok` repository खोलें।
4. **Add file → Upload files** चुनें।
5. `index.html`, `styles.css`, `app.js`, `README.md`, `DEPLOYMENT.md`, `CERTIFICATE-SPEC.md`, `UPLOAD-TO-GITHUB-HINDI.md` और `supabase` folder upload करें। `supabase` folder के अंदर `schema.sql` भी होना चाहिए।
6. **Commit changes** दबाएँ।
7. **Settings → Pages** में Source `Deploy from a branch`, Branch `main`, Folder `/(root)` रखें। अगर ये पहले से सेट है, तो बदलने की ज़रूरत नहीं।
8. एक-दो मिनट बाद Pages के ऊपर दिए **Visit site** लिंक से वेबसाइट खोलें। जरूरत पड़े तो `Ctrl + F5` दबाकर hard refresh करें।

## सही फाइल-संरचना
```text
Sahityik-ShabdLok/
├── index.html
├── styles.css
├── app.js
├── README.md
├── DEPLOYMENT.md
├── CERTIFICATE-SPEC.md
├── UPLOAD-TO-GITHUB-HINDI.md
└── supabase/
    └── schema.sql
```

## अगर वेबसाइट पर सिर्फ़ नाम और एक लाइन दिखे
- जाँचें कि `index.html` repository के root में है, किसी अतिरिक्त subfolder के अंदर नहीं।
- `styles.css` और `app.js` भी उसी स्तर पर होने चाहिए।
- GitHub में `index.html` खोलकर देखें कि उसमें `styles.css` और `app.js` के references मौजूद हैं।
- Commit के बाद Pages deployment पूरा होने दें और `Ctrl + F5` करें।

## फीचर की स्थिति
यह पैकेज responsive static frontend, navigation, साहित्य सेक्शन, ARS Book, founder section और demo interactions देता है। वास्तविक OTP/login, member profiles, submissions का database, Admin/Publisher approval और प्रमाणपत्र जारी करना **अभी चालू backend फीचर नहीं हैं**। इन्हें चलाने के लिए Supabase configuration, सुरक्षा नियम, backend integration और परीक्षण ज़रूरी हैं। GitHub Pages अकेले ये सुविधाएँ नहीं देता।
