# साहित्यिक शब्दलोक — ARS | आदर्श साहित्य

ARS साहित्यिक मंच का responsive frontend package. डिज़ाइन की मुख्य रंग योजना: क्रीम + मैरून + गोल्ड।

## इसमें शामिल है
- `index.html` — मुख्य वेबसाइट
- `styles.css` — responsive styling और रंग-थीम
- `app.js` — navigation और demo interactions
- `supabase/schema.sql` — backend/database setup के लिए शुरुआती SQL schema
- `DEPLOYMENT.md` — deployment और backend checklist
- `UPLOAD-TO-GITHUB-HINDI.md` — GitHub पर सही तरह फाइलें upload करने की हिंदी guide
- `CERTIFICATE-SPEC.md` — certificate workflow specification

## जल्दी से वेबसाइट लाइव करने के लिए
1. ZIP को Extract All करें।
2. ZIP फ़ाइल नहीं, उसके अंदर की `index.html`, `styles.css`, `app.js` और बाकी contents अपनी GitHub repository के root में upload करें।
3. `Settings → Pages` में `main` branch और `/(root)` चुनें।
4. Pages स्क्रीन के `Visit site` लिंक से वेबसाइट खोलें।

विस्तृत चरण `UPLOAD-TO-GITHUB-HINDI.md` में हैं।

## महत्वपूर्ण सीमा
यह frontend package है, production-ready full-stack platform नहीं। वास्तविक OTP authentication, private member accounts, submissions database, Admin/Publisher approval, publishing workflow और certificate generation के लिए backend configuration, access-control policies और security testing अभी करना होगा। Supabase schema एक शुरुआती आधार है; उसे review और test किए बिना production data के लिए उपयोग न करें। कभी भी Supabase `service_role` secret को frontend code या GitHub में न रखें।
